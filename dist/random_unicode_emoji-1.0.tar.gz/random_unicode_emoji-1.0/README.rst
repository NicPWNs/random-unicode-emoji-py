Random Unicode Emoji
====================

A simple Python package to retrieve a random Unicode emoji. 😄


Usage
=====

Import::

    import random-unicode-emoji

Function::

    emoji = random_emoji()
